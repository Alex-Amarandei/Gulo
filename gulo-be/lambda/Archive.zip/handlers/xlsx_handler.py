import json


def handle_xlsx(body_json):
    # Placeholder for XLSX handling logic
    return {
        "statusCode": 501,
        "body": json.dumps({"message": "XLSX download not implemented yet."}),
        "headers": {"Content-Type": "application/json"},
    }

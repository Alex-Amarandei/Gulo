import json


def handle_json(body_json):
    pretty_json = json.dumps(body_json, indent=2)
    return {
        "statusCode": 200,
        "body": json.dumps({"fileContent": pretty_json}),
        "headers": {
            "Content-Type": "application/json",
            "Content-Disposition": "attachment; filename=response.json",
        },
    }

import json
from request_handler import handle_post_request


def lambda_handler(event, context):
    method = event["requestContext"]["http"]["method"]

    if method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
        }

    if method != "POST":
        return {
            "statusCode": 405,
            "body": json.dumps({"message": "Method Not Allowed"}),
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
        }

    body_str = event.get("body", "")
    body_json = json.loads(body_str)
    download_type = body_json.get("downloadType", "")
    response = handle_post_request(body_str, download_type)

    # Ensure CORS headers are added to the response
    response["headers"]["Access-Control-Allow-Origin"] = "*"
    response["headers"]["Access-Control-Allow-Methods"] = "POST, OPTIONS"
    response["headers"]["Access-Control-Allow-Headers"] = "Content-Type"

    return response


def main():
    with open("request.txt", "r") as infile:
        event = json.load(infile)

    context = None
    response = lambda_handler(event, context)
    print(response)


if __name__ == "__main__":
    main()
